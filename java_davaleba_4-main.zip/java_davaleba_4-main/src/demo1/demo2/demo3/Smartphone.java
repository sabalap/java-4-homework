package demo1.demo2.demo3;

public class Smartphone {
    void touchScreen(){
        System.out.println("TouchScreen");
    }
    void printSmartphone(){
        System.out.println("Smartphone");
    }
}
