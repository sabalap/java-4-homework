package demo1.demo2.demo3;

public class Nokia extends Simbian {
    String title;

    public Nokia(String title){
        this.title=title;
    }

}
