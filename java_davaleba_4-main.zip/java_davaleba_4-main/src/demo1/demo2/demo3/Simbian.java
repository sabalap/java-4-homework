package demo1.demo2.demo3;

public class Simbian  {
    public String title;

    void keyboard(){
        System.out.println("keyboard");
    }
    void printSimbian(){
        System.out.println("simbian");
    }

}
