package demo1.demo2;

public interface Sumable {
    int sum(int x,int y);
}
